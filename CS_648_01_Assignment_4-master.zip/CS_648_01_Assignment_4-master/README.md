# Assignment 4

It covers various properties of grids such as:

grid-gap  
grid-template  
grid-row  
grid-column  
grid-area  
grid-template-rows  
grid-template-columns