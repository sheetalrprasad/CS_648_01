## Assignment 2
Changes made in the structure of Assignment 1 for a better front end. I used various tags that would be useful in enhancing the front of the website. The following pages were created and linked:

* home
* about-us
* solutions
* contact-us

#### Tag used
* img
* a
* strong
* em
* ul
* ol