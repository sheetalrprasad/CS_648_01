# Assignment-6
Covers basics of the JavaScript - conditional statement and Loops. The assignment has 8 different parts. Each part has it's own index.html file to run.

### Technologies Used
1. HTML
2. JavScript

### Getting Started
Run **index.html**