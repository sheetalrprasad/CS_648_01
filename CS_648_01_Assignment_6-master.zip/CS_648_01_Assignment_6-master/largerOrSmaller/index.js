var firstNum = parseInt(prompt('Enter first Num'));
var secondNum = parseInt(prompt('Enter Second Num'));

if(firstNum > secondNum){
        document.write('First Num is larger')
} else if( firstNum === secondNum) {
        document.write('Both num are equals')
} else {
        document.write('Second Num is larger')
}