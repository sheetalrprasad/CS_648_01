# Assignment 3

The assignment is divided in 2 parts.

### Part1:
The first part of assignment concerns with the formatting of the index.html

### Part2:
The second part of the assignment addresses the formatting of the index.html, contactus.html, solutions.html, pricing.html, aboutus.html

### CSS Selectors used:
Attribute  
Pseduo selectors  
Pseudo elements  
Descendants  
Multiple Elements  