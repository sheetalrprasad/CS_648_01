### Assignment 5

The assignment consists of basic structures of vecta-corporation website. Created a mordern website using new technologies and frameworks.

#### Technologies Used:

a. HTML  
b. SASS  
c. Gulp  
d. Node

#### Steps to reproduce:

```
1. git clone the repo
2. npm install
3. npx gulp
```
