### Assignment-9
JQuery features & introduces various concepts such as Event handling, commands, selector & form manupulations. This assignment consists of manipulation of DOM by using selector methods and manupulation of events.

#### Technologies
1. HTML
2. JavScript
3. JQuery

##### Getting Started
Run **index.html** under vectaCorp for assignment-9.  
Run **eventsLab.html** under jqueryLab for Lab assignment.