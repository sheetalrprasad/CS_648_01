# Assignment-8
Covers advance concepts of the JavaScript by introducing DOM, BOM, and form manupulations. The assignment consists of creating a Employee managament application that is built upon using the above concepts.

#### Technologies
1. HTML
2. JavScript


Run **index.html**
