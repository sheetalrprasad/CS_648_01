# Assignment-7
This Assignment covers advance concepts of the JavaScript by introducing function, type of functions, event handling.

## Technologies
1. HTML
2. JavScript

##  Getting Started

1. Run **index.html**
