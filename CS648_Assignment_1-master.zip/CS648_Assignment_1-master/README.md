# Vecta Corp. 24/7 365 turnkey vSolutions for your agile ebusiness.  
Vecta Corporation provides **scalable business solutions** to help companies achieve success through revenue increase, cost management, and user satisfaction

## Solutions
## vProspect
## vConvert
## vRetain
<br>

> ### Contact Vecta Corporation
>_Vecta Corporation_   
>555 Technology Place  
>San Diego, CA 92115  
>Tel. (800) 555-5555  

<br>

### Management Team
* _Agnes_, Vice President, Accounting  
* _Damon_, Director of Development  
* _Herbert_, Director of Human Resources  
* _Mike_, Vice President, Marketing  
* _Ferris_, Founder and CEO  

### Created a Web page for Vecta Corp. using basic HTML commands.
### Created Github Repository and updated the README.md file using various markdowns to edit and style the text.