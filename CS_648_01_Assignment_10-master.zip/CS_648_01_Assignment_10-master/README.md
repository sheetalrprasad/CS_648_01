# Assignment-10

### Technologies
1. HTML
2. JavScript
3. JQuery

### Getting Started  
Run **index.html**