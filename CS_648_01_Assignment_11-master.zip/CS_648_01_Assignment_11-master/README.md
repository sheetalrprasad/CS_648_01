# Assignment-11
## Bootstrap
In this assignment we implement the concepts of Bootstrap framework. The inbuilt classes in the framework helps in reducing the necessity of writing boiler-plate code. 

1. Navigation Menu
2. Carousel
3. Collapsible Methods

